# AI Quiz Generator

A simple Python quiz application that generates random multiple-choice questions, checks user answers, and displays the final score. This project is beginner-friendly and helps practice basic Python concepts.

## Features

* Random quiz questions
* Multiple-choice answers
* Instant answer checking
* Final score and percentage

## Technologies Used

* Python 
* Random module

## How to Run

```bash
AI quiz.py
```
