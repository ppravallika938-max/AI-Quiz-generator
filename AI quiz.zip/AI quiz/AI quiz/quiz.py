import random

name = input("Enter your name: ")
print("Welcome", name)

question_bank = [
    {
        "question": "What does CPU stand for?",
        "options": ["Central Process Unit", "Central Processing Unit", "Computer Processing Unit", "Control Processing Unit"],
        "answer": "Central Processing Unit"
    },
    {
        "question": "Which language is used for AI and Machine Learning?",
        "options": ["Python", "HTML", "CSS", "SQL"],
        "answer": "Python"
    },
    {
        "question": "What is the capital of India?",
        "options": ["Mumbai", "Hyderabad", "New Delhi", "Chennai"],
        "answer": "New Delhi"
    },
    {
        "question": "Which keyword is used to define a function in Python?",
        "options": ["func", "function", "define", "def"],
        "answer": "def"
    },
    {
        "question": "What is 10 + 15?",
        "options": ["20", "25", "30", "15"],
        "answer": "25"
    },
    {
        "question": "Which symbol is used for comments in Python?",
        "options": ["//", "#", "<!--", "**"],
        "answer": "#"
    }
]

# AI Quiz Generator (Simulated)
def generate_quiz(num_questions):
    return random.sample(question_bank, num_questions)

# Main Program
print("=" * 40)
print("      AI QUIZ GENERATOR")
print("=" * 40)

name = input("Enter your name: ")

while True:
    try:
        num = int(input("How many questions do you want (1-6)? "))
        if 1 <= num <= 6:
            break
        else:
            print("Please enter a number between 1 and 6.")
    except ValueError:
        print("Please enter a valid number.")

quiz = generate_quiz(num)

score = 0

for i, q in enumerate(quiz, start=1):
    print("\n--------------------------------")
    print(f"Question {i}: {q['question']}")

    for j, option in enumerate(q["options"], start=1):
        print(f"{j}. {option}")

    while True:
        try:
            choice = int(input("Enter your answer (1-4): "))
            if 1 <= choice <= 4:
                break
            else:
                print("Choose between 1 and 4.")
        except ValueError:
            print("Enter a valid number.")

    selected = q["options"][choice - 1]

    if selected == q["answer"]:
        print("✅ Correct!")
        score += 1
    else:
        print("❌ Wrong!")
        print("Correct Answer:", q["answer"])

print("\n" + "=" * 40)
print("Quiz Finished")
print("=" * 40)
print("Name :", name)
print("Score:", score, "/", num)

percentage = (score / num) * 100
print(f"Percentage: {percentage:.2f}%")

if percentage >= 80:
    print("Grade: Excellent ⭐⭐⭐")
elif percentage >= 60:
    print("Grade: Good ⭐⭐")
elif percentage >= 40:
    print("Grade: Average ⭐")
else:
    print("Grade: Keep Practicing 💪")